
/*
* Gamma World Character Generator
*
* Originally by Joe Fulgham @ http://www.holycow.com/joe/
* Expanded and re-coded by Luke Nickerson @ http://deathraygames.com/
*
* Creative Commons (Attribution Non-Commercial Sharealike) 2010
*
*/

function dice_roll (die, dice) {
	  // Rolls (dice)d(die) and adds them together
	  var roll = 0;
	  for (loop=0; loop < dice; loop++) {
	      roll = roll + Math.round(Math.random() * die) % die + 1;
	  }
	  return(roll);
}

// ========= Global Variables ================ \\

var gAncientJunkNameArray = ["15-inch computer monitor","20-lb. dumbell","Punching bag","Bike helmet","Day-glow vest","Exercise treadmill","Exercise treadmill","Cell phone","Ashtray","Electric blender","Hearing aid","Coloring book","Camera flash cube","Portable table saw","Toy gun","Vacuum cleaner","Remote control","Tin of sardines","Inflatable kiddie pool","Nose-hair clipper","Electric razor","Green plastic soldiers","Board game","Bag of hard candy","Kaleidoscope","Slide projector","Toy dump truck","Corporate logo T-shirt","Jug of maple syrup","Earphones","Mini fridge","Pack of antacide tablets","Taxi mileage meter","Umbrella","Wecam","Wireless keyboard","Bottle of nail polish","Swim goggles","Deck of cards","LED light bullb","Laptop computer","Electric toothbrush","Garage-door opener","Bottle of hand lotion","Butane lighter","Bike lock","Golf club (9 iron or your choice)","Foosball table","Interface cable","Digital thermometer","Pgoo stick","Stapler","Tennis racket","Plastic water bottle","Camera lens","Cordless drill","Cell-phone earpiece","String of holiday lights","Water-bubble level","Croquet set","Sci-fi serial on DVD","Radar detector","Wristwatch","Wireless router","Saxophone","Violin","Glue (white)","DVD player","Box of cake mix","Eyeglasses","Gas grill","Printer/scanner","Skateboard","Socket wrench set","Individually wrapped creme-filled yellow sponge cake","Cellophane tape","Electric blanket","Electric fan","Inflatable life vest","Nail clippers","Baby car seat","Tweezers and nail file","Windshield scraper","Cordless mouse","Digital camera","Clock radio","Subwoofer","Tire-pressure gauge","Exercise bike","Construction hazard light","Digital photo frame","Pack of crayons","Smoke detector","8 GB RAM DISK","air compressor","Camcorder","Car stereo","Ceiling fan","Ammo","Stocking cap","Weed whacker"];

var gGearNameArray = [
	"Ancient Junk",				// array number 0
	"Climber's Kit",
	"Canoe",
	"Keelboat",
	"Lantern (8 hours of lamp oil)", 
	"Draft horse (no wagon)", 
	"Riding horse", 
	"Tent", 
	"Wagon", 
	"Binoculars", 
	"Laptop computer", 
	"Duct tape", 
	"Heavy flashlight", 
	"Fuel, 5 gallons", 
	"Generator (8 hours of fuel)", 
	"Night-vision goggles", 
	"Radio cell phone", 
	"Pickup truck", 
	"Water purifier (water not included)", 
	"+2 Rolled Items", 				// array number 19
	"Explorer\'s Kit (Backpack, Bedroll, Canteen, Flint and steel, 10 days Rations (trail), 100 ft Rope.)", 
	"One armor (your choice)", 			// array number 21
	"One melee weapon (your choice)", 
	"One ranged weapon (your choice)"];

var gSkillAbilityAssociationArray = [
	"acrobatics", 	"DEX",
	"athletics", 		"STR",
	"conspiracy", 	"INT",
	"insight", 		"WIS",
	"interaction", 	"CHA",
	"mechanics", 		"INT",
	"nature", 		"WIS",
	"perception", 	"WIS",
	"science", 		"INT",
	"stealth", 		"DEX"];
	

var gAbilityNamesArray = ["Strength", "Constitution", "Dexterity", "Intelligence", "Wisdom", "Charisma"];
var gAbilityAbbrevNamesArray = [
	"STR", //0
	"CON", //1
	"DEX", //2
	"INT", //3
	"WIS", //4
	"CHA"  //5
	];

// =========================== ORIGIN DATA ================== \\

var gRules = eval({
	
	"origin" : [
		{
			"name" : 		"Android",
			"favoredAbility" :	"INT",
			"overCharge" :	"Dark",
			"favoredSkills" :	["science"],
			"initiativeMod" :	0,	"speedMod" :		0,
			"fortitudeMod" :	2, 	"reflexMod" :		0,	"willMod" :		0
		},
		{
			"name" : 		"Cockroach",
			"favoredAbility" :	"CON",
			"overCharge" :	"Bio",
			"favoredSkills" :	[""],
			"initiativeMod" :	0,	"speedMod" :		0,
			"fortitudeMod" :	0, 	"reflexMod" :		2,	"willMod" :		0
		},
		{
			"name" : 		"Doppelganger",
			"favoredAbility" :	"INT",
			"overCharge" :	"Dark",
			"favoredSkills" :	[""],
			"initiativeMod" :	0,	"speedMod" :		0,
			"fortitudeMod" :	0, 	"reflexMod" :		2,	"willMod" :		0
		},
		{
			"name" : 		"Electrokinetic",
			"favoredAbility" :	"WIS",
			"overCharge" :	"Dark",
			"favoredSkills" :	[""],
			"initiativeMod" :	0,	"speedMod" :		0,
			"fortitudeMod" :	0, 	"reflexMod" :		2,	"willMod" :		0
		},
		{
			"name" : 		"Empath",
			"favoredAbility" :	"CHA",
			"overCharge" :	"Psi",
			"favoredSkills" :	[""],
			"initiativeMod" :	0,	"speedMod" :		0,
			"fortitudeMod" :	0, 	"reflexMod" :		0,	"willMod" :		0
		},
		{
			"name" : 		"Felinoid",
			"favoredAbility" :	"DEX",
			"overCharge" :	"Bio",
			"favoredSkills" :	[""],
			"initiativeMod" :	0,	"speedMod" :		0,
			"fortitudeMod" :	0, 	"reflexMod" :		2,	"willMod" :		0
		},
		{
			"name" : 		"Giant",
			"favoredAbility" :	"STR",
			"overCharge" :	"Bio",
			"favoredSkills" :	[""],
			"initiativeMod" :	0,	"speedMod" :		0,
			"fortitudeMod" :	2, 	"reflexMod" :		0,	"willMod" :		0
		},
		{
			"name" : 		"Gravity Controller",
			"favoredAbility" :	"CON",
			"overCharge" :	"Dark",
			"favoredSkills" :	[""],
			"initiativeMod" :	0,	"speedMod" :		0,
			"fortitudeMod" :	0, 	"reflexMod" :		2,	"willMod" :		0
		},
		{
			"name" : 		"Hawkoid",
			"favoredAbility" :	"WIS",
			"overCharge" :	"Bio",
			"favoredSkills" :	[""],
			"initiativeMod" :	0,	"speedMod" :		0,
			"fortitudeMod" :	0, 	"reflexMod" :		0,	"willMod" :		0
		},
		{
			"name" : 		"Hypercognitive",
			"favoredAbility" :	"WIS",
			"overCharge" :	"Psi",
			"favoredSkills" :	[""],
			"initiativeMod" :	0,	"speedMod" :		0,
			"fortitudeMod" :	0, 	"reflexMod" :		2,	"willMod" :		0
		},
		{
			"name" : 		"Mind Breaker",
			"favoredAbility" :	"CHA",
			"overCharge" :	"Psi",
			"favoredSkills" :	[""],
			"initiativeMod" :	0,	"speedMod" :		0,
			"fortitudeMod" :	0, 	"reflexMod" :		0,	"willMod" :		2
		},
		{
			"name" : 		"Mind Coercer",
			"favoredAbility" :	"CHA",
			"overCharge" :	"Psi",
			"favoredSkills" :	[""],
			"initiativeMod" :	0,	"speedMod" :		0,
			"fortitudeMod" :	0, 	"reflexMod" :		0,	"willMod" :		2
		},
		{
			"name" : 		"Plant",
			"favoredAbility" :	"CON",
			"overCharge" :	"Bio",
			"favoredSkills" :	[""],
			"initiativeMod" :	0,	"speedMod" :		0,
			"fortitudeMod" :	2, 	"reflexMod" :		0,	"willMod" :		0
		},
		{
			"name" : 		"Pyrokinetic",
			"favoredAbility" :	"WIS",
			"overCharge" :	"Psi",
			"favoredSkills" :	[""],
			"initiativeMod" :	0,	"speedMod" :		0,
			"fortitudeMod" :	0, 	"reflexMod" :		0,	"willMod" :		0
		},
		{
			"name" : 		"Radioactive",
			"favoredAbility" :	"CON",
			"overCharge" :	"Dark",
			"favoredSkills" :	[""],
			"initiativeMod" :	0,	"speedMod" :		0,
			"fortitudeMod" :	2, 	"reflexMod" :		0,	"willMod" :		0
		},
		{
			"name" : 		"Rat Swarm",
			"favoredAbility" :	"DEX",
			"overCharge" :	"Bio",
			"favoredSkills" :	[""],
			"initiativeMod" :	0,	"speedMod" :		0,
			"fortitudeMod" :	0, 	"reflexMod" :		0,	"willMod" :		0
		},
		{
			"name" : 		"Seismic",
			"favoredAbility" :	"STR",
			"overCharge" :	"Dark",
			"favoredSkills" :	[""],
			"initiativeMod" :	0,	"speedMod" :		-1,
			"fortitudeMod" :	0, 	"reflexMod" :		0,	"willMod" :		0
		},
		{
			"name" : 		"Speedster",
			"favoredAbility" :	"DEX",
			"overCharge" :	"Psi",
			"favoredSkills" :	[""],
			"initiativeMod" :	0,	"speedMod" :		0,
			"fortitudeMod" :	0, 	"reflexMod" :		2,	"willMod" :		0
		},
		{
			"name" : 		"Telekinetic",
			"favoredAbility" :	"INT",
			"overCharge" :	"Psi",
			"favoredSkills" :	[""],
			"initiativeMod" :	0,	"speedMod" :		0,
			"fortitudeMod" :	0, 	"reflexMod" :		2,	"willMod" :		0
		},
		{
			"name" : 		"Yeti",
			"favoredAbility" :	"STR",
			"overCharge" :	"Bio",
			"favoredSkills" :	[""],
			"initiativeMod" :	0,	"speedMod" :		0,
			"fortitudeMod" :	0, 	"reflexMod" :		0,	"willMod" :		0
		},
		{
			"name" : 		"Engineered Human",
			"favoredAbility" :	"CHA",
			"overCharge" :	"All",
			"favoredSkills" :	[""],
			"initiativeMod" :	0,	"speedMod" :		0,
			"fortitudeMod" :	1, 	"reflexMod" :		1,	"willMod" :		1
		},
	]

});


/*
var gOriginArray = [
	"Android",		"Cockroach", 	"Doppelganger",	"Electrokinetic", 	"Empath",
	"Felinoid",		"Giant", 	"Gravity Controller", "Hawkoid", 		"Hypercognitive",
	"Mind Breaker",	"Mind Coercer","Plant",		"Pyrokinetic",	"Radioactive",
	"Rat Swarm",		"Seismic",	"Speedster",		"Telekinetic",	"Yeti",
	"Engineered Human"];

var gOriginFavoredAbilityArray = [
	"INT", "CON", "INT", "WIS", "CHA",
	"DEX", "STR", "CON", "WIS", "WIS",
	"CHA", "CHA", "CON", "WIS", "CON",
	"DEX", "STR", "DEX", "INT", "STR",
	"CHA"];
	
var gOriginOverChargeArray = [
	"Dark", "Bio", "Dark", "Dark", "Psi",
	"Bio", "Bio", "Dark", "Bio", "Psi",
	"Psi", "Psi", "Bio", "Psi", "Dark",
	"Bio", "Dark", "Psi", "Psi", "Bio",
	"All"];	
	
var gOriginInitiativeBonusArray = [
	0, 0, 0, 0, 0,
	0, 0, 0, 0, 0,
	0, 0, 0, 0, 0,
	0, 0, 0, 0, 0,
	0];
	
var gOriginMoveBonusArray = [
	0, 0, 0, 0, 0,
	0, 0, 0, 0, 0,
	0, 0, 0, 0, 0,
	0, -1, 0, 0, 0,
	0];
	
var gOriginFortitudeBonusArray = [
	2, 0, 0, 0, 0,
	0, 2, 0, 0, 0,
	0, 0, 2, 0, 2,
	0, 0, 0, 0, 0,
	1];

var gOriginReflexBonusArray = [
	0, 2, 2, 2, 0,
	2, 0, 2, 0, 2,
	0, 0, 0, 0, 0,
	0, 0, 2, 2, 0,
	1];
	
var gOriginWillBonusArray = [
	0, 0, 0, 0, 0,
	0, 0, 0, 0, 0,
	2, 2, 0, 0, 0,
	0, 0, 0, 0, 0,
	1];
*/



// ============= The character object ============== \\




function CharacterObject ()
{
	this.level = 1;
	this.name = "";
	this.primary = 0;
	this.secondary = 19;
	this.maxHitPoints = 12;
	
	this.STR = 0;
	this.CON = 0;
	this.DEX = 0;
	this.INT = 0;
	this.WIS = 0;
	this.CHA = 0;
	
	this.inventoryNameArray = [];

	// Additional modifiers to various scores; these do not include ability/level/origin modifiers
	this.initiativeMod = 0;
	this.speedMod = 0;
	this.fortitudeMod = 0;
	this.reflexMod = 0;
	this.willMod = 0;
	
	// Base skills; these scores do not include ability/level/origin modifiers
	//	Final skill score is calulated in getSkillByName function
	this.acrobatics = 0;
	this.athletics = 0;
	this.conspiracy = 0;
	this.insight = 0;
	this.interaction = 0;
	this.mechanics = 0;
	this.nature = 0;
	this.perception = 0;
	this.science = 0;
	this.stealth = 0;
	
	
	this.getBloodied = function () {
		return (Math.floor(this.maxHitPoints/2));
	}

	this.getInitiative = function () {
		return (this.level + gOriginInitiativeBonusArray[this.primary] + this.initiativeMod);
	}
	this.getSpeed = function () {
		return (6 + gOriginMoveBonusArray[this.primary] + this.speedMod);
	}
	this.getFortitude = function () {
		var f = 10 + this.level + this.fortitudeMod;
		f += gOriginFortitudeBonusArray[this.primary] + gOriginFortitudeBonusArray[this.secondary];
		f += higherStatBonus(this.STR, this.CON);
		return (f);
	}
	this.getReflex = function () {
		var r = 10 + this.level + this.reflexMod;
		r += gOriginReflexBonusArray[this.primary] + gOriginReflexBonusArray[this.secondary];
		r += higherStatBonus(this.DEX, this.INT);
		return (r);
	}	
	this.getWill = function () {
		var r = 10 + this.level + this.willMod;
		r += gOriginWillBonusArray[this.primary] + gOriginWillBonusArray[this.secondary];
		r += higherStatBonus(this.WIS, this.CHA);
		return (r);
	}	

	this.getAbilityByName = function (aname) {
		return (eval("this."+aname));
	}
	
	this.setAbilityByName = function (aname, score) {
		eval("this."+aname+"="+score);
	}

	this.getSkillByName = function (skillname) {
		var skillScore = eval("this."+skillname);
		var associatedAbility;
		// Look up the ability that's associated with the skill
		for (i=0; i < gSkillAbilityAssociationArray.length; i++) {
			if (gSkillAbilityAssociationArray[i] == skillname) {
				associatedAbility = gSkillAbilityAssociationArray[i+1];
				break;
			}
		}
		skillScore += statBonus(this.getAbilityByName(associatedAbility));
		skillScore += this.level;
	}
	
	this.getFortitudeModText = function () {
		var t = '<span title="10 + level + higher of str or con mod + origin bonus + other mods">';
		t += '10 + '+this.level+' + '+higherStatBonus(this.STR, this.CON)+' + ';
		t += gOriginFortitudeBonusArray[this.primary] + gOriginFortitudeBonusArray[this.secondary];
		t += ' + '+this.fortitudeMod+'</span>';
	}
	
}

var gChar = new CharacterObject();


// ================= Functions =============== \\


function statBonus (statValue) {
	  // Determines bonus from a given stat, including negatives.
	  statValue = parseInt((statValue-10)/2);
	  return(statValue);
}

function higherStatBonus (statVal1, statVal2) {
	if (statVal1 > statVal2) return statBonus(statVal1);
	else return statBonus(statVal2);
}

function getStats (c) {
	  // Rolls all stats sets skills = level

	  var skillAcrobatics = 1;
	  var skillAthletics = 1;
	  var skillConspiracy = 1;
	  var skillInsight = 1;
	  var skillInteraction = 1;
	  var skillMechanics = 1;
	  var skillNature = 1;
	  var skillPerception = 1;
	  var skillScience = 1;
	  var skillStealth = 1;


	  // Can I combine these two switches?  Probably.
	  switch (c.primary+1) {
	      case 1: skillScience+=4;  break;
	      case 2: skillMechanics+=4;  break;
	      case 3: skillConspiracy+=4; break;
	      case 4: skillMechanics+=4;  break;
	      case 5: skillInsight+=4;  break;
	      case 6: skillStealth+=4;  break;
	      case 7: skillAthletics+=4;  break;
	      case 8: skillAthletics+=4;  break;
	      case 9: skillPerception+=4; break;
	      case 10: skillInsight+=4;   break;
	      case 11: skillInteraction+=4;  break;
	      case 12: skillInteraction+=4;   break;
	      case 13: skillNature+=4;  break;
	      case 14: skillInteraction+=4; break;
	      case 15: skillScience+=4; break;
	      case 16: skillStealth+=4; break;
	      case 17: skillAthletics+=4; break;
	      case 18: skillAcrobatics+=4;  break;
	      case 19: skillMechanics+=4; break;
	      case 20: skillNature+=4; break;
	      case 21: skillScience+=4; skillInteraction+=4; break;
	  }

	  switch (c.secondary+1) {
	      case 1: skillScience+=4;  break;
	      case 2: skillMechanics+=4;  break;
	      case 3: skillConspiracy+=4; break;
	      case 4: skillMechanics+=4;  break;
	      case 5: skillInsight+=4;  break;
	      case 6: skillStealth+=4;  break;
	      case 7: skillAthletics+=4;  break;
	      case 8: skillAthletics+=4;  break;
	      case 9: skillPerception+=4; break;
	      case 10: skillInsight+=4;   break;
	      case 11: skillInteraction+=4;  break;
	      case 12: skillInteraction+=4;   break;
	      case 13: skillNature+=4;  break;
	      case 14: skillInteraction+=4; break;
	      case 15: skillScience+=4; break;
	      case 16: skillStealth+=4; break;
	      case 17: skillAthletics+=4; break;
	      case 18: skillAcrobatics+=4;  break;
	      case 19: skillMechanics+=4; break;
	      case 20: skillNature+=4; break;
	      case 21: skillScience+=4; skillInteraction+=4; break;
	  }




	  statsOut ='<p>Acrobatics: ' + skillAcrobatics + '<br />Athletics: ' + skillAthletics + '<br />Conspiracy: ' + skillConspiracy + '<br />Insight: ' + skillInsight;
	  statsOut +='<br />Interaction: ' + skillInteraction + '<br />Mechanics: ' + skillMechanics + '<br />Nature: ' + skillNature + '<br />Perception: ' + skillPerception;
	  statsOut +='<br />Science: ' + skillScience + '<br />Stealth: ' + skillStealth + '</p>';

	  
	  return(statsOut);
}

// ============= HTML OUTPUT FUNCTIONS =========== \\

function getGearHTML (c) {
	var gearOut = '<ul>';
	var invCount = 0;	   
	for (g=0; g < c.inventoryNameArray.length; g++) {
		gearOut += '<li>' + c.inventoryNameArray[g] + '</li>';
		invCount++;
	}
	for (x=0; x < 12-invCount; x++) {
		gearOut += '<li></li>';
	}	
	gearOut += '<li></li></ul>';
	return(gearOut);
}

function getOriginsHTML (c) {
	originsOut = '<ol><li>' + gOriginArray[c.primary] + '</li><li>' + gOriginArray[c.secondary] + '</li></ol>';
	return originsOut;
}

function getOriginTraitsHTML(c) {
	traitsOut = '<ul>';
	traitsOut += '<li>+2 to ' + gOriginOverChargeArray[c.primary] + ' overcharge</li>';
	traitsOut += '</ul>';
	return traitsOut;
}

function getSkillsHTML (c) {
	// ** Needs to be fixed
	return getStats(c);
}

function getAbilityHTML (c) {
	var abilityOut = '<ul>';
	for (a=0; a < gAbilityAbbrevNamesArray.length; a++) {
		var AbbrevName = gAbilityAbbrevNamesArray[a];
		var score = c.getAbilityByName(AbbrevName);
		abilityOut += '<li><label for="' + AbbrevName + '">' + AbbrevName + '</label>';
		abilityOut += '<span class="score" id="' + AbbrevName + '">' + score + '</span>';
		var mod = statBonus(score);
		abilityOut += '<span class="mods">( ' + ((mod >= 0) ? '+ ':'- ') + Math.abs(mod);
		abilityOut += ' )</span></li>';
	}
	abilityOut += '</ul>';
	return abilityOut;
}

// ============== GENERATE CHARACTER - Randomize Functions ============== \\

function setRandomOrigin (c)
{
	// Roll Primary Origin 
	c.primary = dice_roll(20,1)-1;
	// Roll Secondary Origin
	c.secondary = dice_roll(20,1)-1;
	// If both origins are the same, then Secondary is Engineered Human
	if(c.primary==c.secondary) {
		c.secondary=20;
	}
}

function setRandomGear (c)
{
	// Give character starter gear, then roll for random gear and ancient junk
	c.inventoryNameArray = [
		gGearNameArray[21],
		gGearNameArray[22],
		gGearNameArray[23],
		gGearNameArray[20]
		];
	c.ancientJunkArray = [];		// start with no Ancient Junk
	gearRolls = dice_roll(4,1) + 1;
	for (gearLoop=0; gearLoop < gearRolls; gearLoop++)
	{
		gearResult = dice_roll(20,1) - 1;		// number 0-19
		c.inventoryNameArray[c.inventoryNameArray.length] = gGearNameArray[gearResult];
		if (gearResult==19) {
			gearRolls += 2;
		} else if (gearResult==0) {
			c.inventoryNameArray[c.inventoryNameArray.length] = gAncientJunkNameArray[(dice_roll(100,1)-1)];
			c.inventoryNameArray[c.inventoryNameArray.length] = gAncientJunkNameArray[(dice_roll(100,1)-1)];
		}
	}
}

function setRandomAbilities (c)
{
	// Generate randomly, then adjust for origins
	c.STR = dice_roll(6,3);
	c.CON = dice_roll(6,3);
	c.DEX = dice_roll(6,3);
	c.INT = dice_roll(6,3);
	c.WIS = dice_roll(6,3);
	c.CHA = dice_roll(6,3);
	
	var Ability1 = gOriginFavoredAbilityArray[c.primary];
	var Ability2 = gOriginFavoredAbilityArray[c.secondary];
	if (Ability1 == Ability2 && c.getAbilityByName(Ability1) < 20)
		c.setAbilityByName(Ability1, 20);
	else {
		if (c.getAbilityByName(Ability1) < 18) 
			c.setAbilityByName(Ability1, 18);
		if (c.getAbilityByName(Ability2) < 16)
			c.setAbilityByName(Ability2, 16);
	}
}

function setRandomSkills (c)
{
	c.acrobatics = 0;
	c.athletics = 0;
	c.conspiracy = 0;
	c.insight = 0;
	c.interaction = 0;
	c.mechanics = 0;
	c.nature = 0;
	c.perception = 0;
	c.science = 0;
	c.stealth = 0;
	// One random skill gets a +4 bonus
	randomSkill = dice_roll(10,1);
	switch(randomSkill) {
		case 1: c.acrobatics+=4; break;
		case 2: c.athletics+=4; break;
		case 3: c.conspiracy+=4; break;
		case 4: c.insight+=4; break;
		case 5: c.interaction+=4; break;
		case 6: c.mechanics+=4; break;
		case 7: c.nature+=4; break;
		case 8: c.perception+=4; break;
		case 9: c.science+=4; break;
		case 10: c.stealth+=4; break;
	}
}


// ============== GENERATE CHARACTER - Main Function ============== \\
 
function generateChar() 
{	  
	gChar.level = 1;
	gChar.name = "";

	// Set origins
	setRandomOrigin(gChar);
	  
	// give character random gear / ancient junk
	setRandomGear(gChar);
	
	// Set character's ability scores
	setRandomAbilities(gChar);

	// Set random skill
	setRandomSkills(gChar);

	// Set character's hitpoints: base 12 + con
	gChar.maxHitPoints = 12 + gChar.CON;
		
		
	// Update the HTML using jquery
	
	$('#charactersheet').fadeOut("fast").slideUp("fast", function() {
	
	  $('#name-content').html(		gChar.name);
	  $('#level-content').html(		gChar.level);
	  $('#origin-content').html(	getOriginsHTML(gChar));
	  $('#origintraits-content').html(	getOriginTraitsHTML(gChar));
	  $('#powers-content').html(	'Not available yet');
	  $('#ability-content').html(	getAbilityHTML(gChar));
	  $('#skills-content').html(	getSkillsHTML(gChar));
	  
	  $('#hp-content').html(		gChar.maxHitPoints);
	  $('#bloodied-content').html(	gChar.getBloodied());
	  $('#speed-content').html(		gChar.getSpeed());
	  
	  $('#ac-content').html(		'N/A');
	  $('#ac-mod-content').html(	'N/A');
	  $('#fortitude-content').html(	gChar.getFortitude());
	  $('#fortitude-mod-content').html(gChar.getFortitudeModText());
	  $('#reflex-content').html(	gChar.getReflex());
	  $('#reflex-mod-content').html(	'10 + level + higher of dex or int mod + origin bonus');
	  $('#will-content').html(		gChar.getWill());
	  $('#will-mod-content').html(	'10 + level + higher of wis or cha mod + origin bonus');
	  
	  $('#attacks-content').html(	'Not available yet');
	  $('#gear-content').html(		getGearHTML(gChar));
	  
	  $('#charactersheet').fadeIn("fast").slideDown("slow");
	});
}


